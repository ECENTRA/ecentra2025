$('#toggle').click(function() {
   $(this).toggleClass('active');
   $('#overlay').toggleClass('open');
   $('.socialmedia_nav').toggleClass('opennav');
   $('.socialmedia_nav2').toggleClass('opennav');
  });